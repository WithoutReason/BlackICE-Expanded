Usage policy can be found here: https://kaiserreich.wikia.com/wiki/Usage_Policy

We have a website that hosts all our GFX in an easy to search fashion: https://wyandotte.github.io/hoi4-icon-search/

Credit to the wonderful Kaiserreich GFX team!